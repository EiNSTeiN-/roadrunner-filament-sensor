import board
import neopixel
import busio
import digitalio
from as5600 import AS5600
from i2ctarget import I2CTarget
import struct
import gc

MODE = "uart"
# MODE = "i2c"

I2C_TARGET_ADDRESS = 64

class Colors:
  Off = (0, 0, 0)
  Magnet_Problem = (255, 0, 0)
  Filament_Not_Present = (128, 0, 128)
  Filament_Present = (0, 0, 255)
  Filament_Rotating = (0, 255, 0)

class Pins:
  NEOPIXEL = board.NEOPIXEL

  AS5600_DIR = board.GP9
  AS5600_SDA = board.GP10
  AS5600_SCL = board.GP11

  IR_OUT = board.GP0

  # when MODE=uart
  UART_TX = board.GP4
  UART_RX = board.GP5

  # when MODE=i2c
  I2C_TARGET_SDA = board.GP4
  I2C_TARGET_SCL = board.GP5
  
class MagnetState:
  NOT_DETECTED = 1
  TOO_WEAK = 2
  TOO_STRONG = 3
  DETECTED = 4

class FilamentSensor:
  ANGLE_BITMASK = 0b111

  def __init__(self):
    self.pixels = neopixel.NeoPixel(Pins.NEOPIXEL, 1, auto_write=True, pixel_order=neopixel.RGB)
    self.set_color(Colors.Off)

    self.as5600_dir = digitalio.DigitalInOut(Pins.AS5600_DIR)
    self.as5600_dir.direction = digitalio.Direction.OUTPUT
    self.as5600_dir.value = True

    self.ir_presence = digitalio.DigitalInOut(Pins.IR_OUT)
    self.ir_presence.direction = digitalio.Direction.INPUT

    self.i2c = busio.I2C(scl=Pins.AS5600_SCL, sda=Pins.AS5600_SDA)
    self.as5600 = AS5600(self.i2c)
    self.as5600.zero_position(0)
    self.as5600.max_position(4095) # full uninterrupted 12 bits range
    self.as5600.hysteresis(3)

    self._magnet_state = None
    self._angle = None
    self._angle_change = 0
    self._filament_present = None

  def set_color(self, color):
    self.pixels[0] = color

  def color(self):
    return self.pixels[0]

  def update_filament_presence(self):
    self._filament_present = self.ir_presence.value

  def filament_present(self):
    return self._filament_present
  
  def update_magnet_state(self):
    if not self.as5600.magnet_detected():
      self._magnet_state = MagnetState.NOT_DETECTED
    else:
      if self.as5600.magnet_too_weak():
        self._magnet_state = MagnetState.TOO_WEAK
      elif self.as5600.magnet_too_strong():
        self._magnet_state = MagnetState.TOO_STRONG
      else:
        self._magnet_state = MagnetState.DETECTED
  
  def magnet_state(self):
    if self._magnet_state is None:
      self.update_magnet_state()
    return self._magnet_state

  def update(self):
    self.update_magnet_state()

    if self._magnet_state != MagnetState.DETECTED:
      if self.color() == Colors.Off:
        self.set_color(Colors.Magnet_Problem)
      else:
        self.set_color(Colors.Off)
    elif self._filament_present != (present := self.ir_presence.value):
      if present:
        print("Filament LOADED")
      else:
        print("Filament UNLOADED")

      self._filament_present = present
    elif not self._filament_present:
      self.set_color(Colors.Filament_Not_Present)
    else:
      self.set_color(Colors.Filament_Present)

      angle = self.as5600.angle()
      if self._angle is None:
        self._angle = angle
        return

      if self._angle & ~FilamentSensor.ANGLE_BITMASK == angle & ~FilamentSensor.ANGLE_BITMASK:
        return

      change = angle - self._angle
      if abs(change) > 2048:
        if self._angle > 2048:
          change = (angle + 4096) - self._angle
        else:
          change = (angle - 4096) + self._angle
      self._angle_change += change

      print("Angle changed: change=%u angle=%.2f" % (change, angle / 4096. * 360.))

      self._angle = angle
  
  def reset_angle_change(self):
     """ Return 'change' value since it was last reset, and reset it to zero. """
     change = self._angle_change
     self._angle_change = 0
     return change
  
  def angle_change(self):
     return self._angle_change


# uart = busio.UART(Pins.UART_TX, Pins.UART_RX, baudrate=40000)
# while True:
#     uart.write(b'a')
#     data = uart.read(1)  # read up to 32 bytes

#     if data is None:
#       sensor.update()
#       regs.set_magnet_state(sensor.magnet_state())
#       regs.set_filament_presence(sensor.filament_present())
#       regs.set_angle_change(sensor.angle_change())
#     else:
#         # led.value = True

#         # # convert bytearray to string
#         # data_string = ''.join([chr(b) for b in data])
#         # print(data_string, end="")

#         # led.value = False
        
#         print('uart data recv', repr(data))  # this is a bytearray type

@micropython.native
def i2c_loop(device):
  magnet_state = None
  filament_presence = None
  index = None
  sensor = FilamentSensor()

  while True:
    r = device.request()
    if not r and index is None:
      sensor.update()
      magnet_state = bytes([sensor.magnet_state()])
      filament_presence = bytes([1 if sensor.filament_present() else 0])
      continue
    if r.address == I2C_TARGET_ADDRESS:
      if not r.is_read:  # Main write which is Selected read
        b = r.read(1)
        if not b or b[0] not in (0, 1, 2):
          continue
        index = b[0]
      elif r.is_read:  # Combined transfer: This is the Main read message
        if index is None:
          continue
        if index == 0:
          r.write(magnet_state)
        elif index == 1:
          r.write(filament_presence)
        elif index == 2:
          angle_change = sensor.reset_angle_change()
          r.write(struct.pack('<l', angle_change))
        index = None
    else:
      print('Tried to read unknown address %02x' % (r.address, ))

@micropython.native
def _calc_crc8(data):
    # Generate a CRC8-ATM value for a bytearray
    crc = 0
    for b in data:
        for i in range(8):
            if (crc >> 7) ^ (b & 0x01):
                crc = (crc << 1) ^ 0x07
            else:
                crc = (crc << 1)
            crc &= 0xff
            b >>= 1
    return crc

def _tmc_reg_response(reg, val):
  msg = bytearray([0x05, 0xff, reg])
  msg.extend(struct.pack('<l', val))
  msg.extend([_calc_crc8(msg)])
  print('response', len(msg), repr(msg))
  print('should receive:', repr(_add_serial_bits(msg)))
  return msg

def _add_serial_bits(data):
    # Add serial start and stop bits to a message in a bytearray
    out = 0
    pos = 0
    for d in data:
        b = (d << 1) | 0x200
        out |= (b << pos)
        pos += 10
    res = bytearray()
    for i in range((pos+7)//8):
        res.append((out >> (i*8)) & 0xff)
    return res

TMC_READ_REG = 0xf5

@micropython.native
def uart_loop(device):
  sensor = FilamentSensor()

  tx = digitalio.DigitalInOut(Pins.UART_TX)
  tx.direction = digitalio.Direction.OUTPUT
  tx.value = False

  while True:
    data = device.read(4)  # read up to 32 bytes

    if data is None:
      sensor.update()
    else:
      print('recv', repr(data))  # this is a bytearray type
      if data[0] == TMC_READ_REG:
        addr = data[1]
        reg = data[2]
        crc = data[3]

        # data = bytearray(b'\xff\xff\xff\xff\xff\xff\xff\xff')
        # # data.extend([_calc_crc8(data)])
        # print('data', repr(data))
        # device.write(data)

        # print('should receive:', repr(_add_serial_bits(data)))

        if _calc_crc8([TMC_READ_REG, addr, reg]) != crc:
          print('Invalid CRC received')
          continue
      
        continue

        if reg == 0:
          device.write(_tmc_reg_response(reg, sensor.magnet_state()))
        elif reg == 1:
          device.write(_tmc_reg_response(reg, 1 if sensor.filament_present() else 0))
        elif reg == 2:
          angle_change = sensor.reset_angle_change()
          device.write(_tmc_reg_response(reg, angle_change))

print('Started.')

if MODE == "uart":
  uart = busio.UART(None, Pins.UART_RX, baudrate=40000)
  uart_loop(uart)
elif MODE == "i2c":
  with I2CTarget(Pins.I2C_TARGET_SCL, Pins.I2C_TARGET_SDA, (I2C_TARGET_ADDRESS, )) as device:
    i2c_loop(device)
